import numpy as np, pandas as pd, torch
from torch import nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, silhouette_score

np.random.seed(42)
torch.manual_seed(42)

# Acquisition
data = load_breast_cancer(as_frame=True)
df = data.frame.copy()
X = df[data.feature_names]
y = df["target"]

# Basic cleaning checks
df = df.drop_duplicates().reset_index(drop=True)
print("Missing values:", int(df.isna().sum().sum()))
print("Rows:", len(df))

# Standardized features for modeling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Unsupervised learning
scores = []
for k in range(2, 6):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    scores.append((k, km.inertia_, silhouette_score(X_scaled, labels)))
score_df = pd.DataFrame(scores, columns=["k","inertia","silhouette"])
best_k = int(score_df.loc[score_df["silhouette"].idxmax(),"k"])
km = KMeans(n_clusters=best_k, random_state=42, n_init=10)
clusters = km.fit_predict(X_scaled)
print("Best k:", best_k)
print("Silhouette:", silhouette_score(X_scaled, clusters))

# Supervised learning
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.20, stratify=y, random_state=42)
clf = Pipeline([("scaler", StandardScaler()),
                ("model", LogisticRegression(max_iter=5000, random_state=42))])
clf.fit(Xtr,ytr)
pred = clf.predict(Xte)
prob = clf.predict_proba(Xte)[:,1]
print("Logistic accuracy:", accuracy_score(yte,pred))
print("Precision:", precision_score(yte,pred))
print("Recall:", recall_score(yte,pred))
print("F1:", f1_score(yte,pred))
print("ROC-AUC:", roc_auc_score(yte,prob))

# Deep learning
Xtr, Xte, ytr, yte = train_test_split(X.values.astype(np.float32), y.values.astype(np.int64),
                                      test_size=0.20, stratify=y, random_state=42)
s = StandardScaler()
Xtr = s.fit_transform(Xtr).astype(np.float32)
Xte = s.transform(Xte).astype(np.float32)
train_loader = DataLoader(TensorDataset(torch.tensor(Xtr),torch.tensor(ytr)), batch_size=32, shuffle=True)

class MLP(nn.Module):
    def __init__(self,n):
        super().__init__()
        self.net=nn.Sequential(nn.Linear(n,64),nn.ReLU(),nn.Dropout(.2),
                               nn.Linear(64,32),nn.ReLU(),nn.Dropout(.2),nn.Linear(32,2))
    def forward(self,x): return self.net(x)

net=MLP(Xtr.shape[1])
loss_fn=nn.CrossEntropyLoss()
opt=torch.optim.Adam(net.parameters(),lr=.001,weight_decay=1e-4)

for epoch in range(30):
    net.train()
    for xb,yb in train_loader:
        opt.zero_grad()
        loss=loss_fn(net(xb),yb)
        loss.backward()
        opt.step()

net.eval()
with torch.no_grad():
    p=net(torch.tensor(Xte)).argmax(1).numpy()
print("Deep learning accuracy:", accuracy_score(yte,p))
